#!/usr/bin/env python
#-*- coding:utf-8 -*-


# shitu_log

STL = {
        "shw": 0,
        "clk": 1,
        "price": 2,
        "cn": 5,
        "searchid": 6,
        "cmatch": 9,
        "winfoid": 11,
        "rank": 12,
        "tag": 13,
        "userid": 17,
        "wordid": 18,
        "bid": 19,
        "title": 24,
        "desc1": 25,
        "desc2": 26,
        "minbid": 33,
        "showurl": 51,
        "CLICK_Q": 64,
        "url": 120
    }


# roi_log

ROIL = { 
        "clk" : 0, 
        "conv" : 1, 
        "roitype" : 2,
        "cn" : 42,
        "price": 39,
        "cmatch": 46,
        "tag": 50,
        "userid": 54,
        "wordid": 55
      }

# asp_log

ASPL = {
        "apres":22
       }

ASPL_APRES = {
              "unitid":2,
              "planid":3,
              "userid":4,
              "click_q":68,
              "FCADV_LOGKEY_BUDGET_THROTTLING_STAT_INFO":117, \
              # bt_pr(bt ori pr)%bt_pp_pr(tuned_pp_pr)%bt_ppim_pr(tuned_ppim_pr)%target_charge_ratio%real_charge_ratio%bt_tag
              "FCADV_LOGKEY_BIDDING_FRAMEWORK":149,
              "split_ad":",",
              "split_column":"_"
             }

ASPL_APRES_BT = {
                 "bt_pr":0,
                 "tuned_pp_pr":1,
                 "tuned_ppim_pr":2,
                 "target_charge_ratio":3,
                 "real_charge_ratio":4,
                 "bt_tag":5,
                 "split":'%'
                }

# external traffic cmatch
EXT_C = ("230", "226", "231")

# fc pc cmatch
FC_PC_C = ("225", "204")

# base data format one column
BASE_INDEX_LIST = [
                   STL["wordid"],
                   STL["userid"],
                   STL["cmatch"],
                   STL["tag"],
                   STL["cn"],
                   STL["price"],
                   STL["clk"],
                   STL["bid"],
                   STL["shw"],
                   STL["searchid"],
                   STL["rank"]
                  ]

# base data format two column
ROI_BASE_INDEX_LIST = [
                   ROIL["wordid"],
                   ROIL["userid"],
                   ROIL["cmatch"],
                   ROIL["cn"],
                   ROIL["price"],
                   ROIL["clk"],
                   ROIL["conv"],
                   ROIL["tag"]
                  ]
