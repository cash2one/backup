#!/usr/bin/env python
# -*- coding:gb2312 -*-
import sys
from UserDict import UserDict

class bse_parser_t(UserDict):
    '''The helper class to parse a bse log line easily
        #��bse��־�У�һ����־����һ�����
    '''

    def __init__(self, line = None):
        UserDict.__init__(self)
        self.is_good = 0
        self.is_bad = 0
        self.refresh(line)

    def refresh(self, line = None):
        if line:
            ori = line.split('   ');
            ubs = ori[1].split('\t');
            self.is_good = ubs[5]
            self.is_bad = ubs[6]
            self.shitu_line = ori[2]
            return 0
        return -1
    

