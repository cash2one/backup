#!/usr/bin/env python
# -*- coding:gb2312 -*-
import sys
from UserDict import UserDict
#�Ʒ���־parser

class drd_parser_t(UserDict):
    '''The helper class to parse a jifei log line easily
    '''
    idx = {
        'clicktype' : 0 , 
        'userid' : 1 , 
        'planid' : 2 , 
        'unitid' : 3 , 
        'winfoid' : 4 , 
        'query' : 5 , 
        'wordid' : 6 , 
        'descid' : 7 , 
        'bid' : 8 , 
        'price' : 9 , 
        'balance' : 10 , 
        'cashrate' : 11 , 
        'orderrow' : 12 , 
        'cmatch' : 13 , 
        'wmatch' : 14 , 
        'cntnid' : 15 , 
        'rank' : 16 , 
        'disprate' : 17 , 
        'sid' : 18 , 
        'searchid' : 18 , 
        'dispip' : 19 , 
        'clkip' : 20 , 
        'provid' : 21 , 
        'cityid' : 22 , 
        'disptime' : 23 ,  #2012-10-12 23:00:01
        'clktime' : 24 , 
        'chargetime' : 25 , 
        'feild_k' : 26 , 
        'cn' : 33 , 
    }
    def __init__(self, line = None):
        UserDict.__init__(self)
        self.refresh(line)

    def refresh(self, line = None):
        if line:
            self.cols = list()
            self.cols.extend(line.strip().split('\t'))
            return 0
        return -1

    def __getitem__(self, key):
        # get key index in cols
        if isinstance(key, int):
            keyidx = key
        else:
            if key not in self.idx:
                raise KeyError
            keyidx = self.idx[key]
        if keyidx >= len(self.cols):
            raise KeyError
        return self.cols[keyidx]

    def __getattr__(self, key):
        return self[key]

    def explain(self):
        Sorted_lst = sorted( self.idx.items(), lambda x, y: cmp(x[1],y[1]))   
        for item in Sorted_lst :
            key = item[0]
            idx = item[1]
            print '%s [%s] : %s'%(key,idx, self[key])
    
if __name__ == "__main__":
    cols = drd_parser_t()
    line_no = 0
    for line in sys.stdin:
        cols.refresh(line)
        line_no += 1
        print '**********************\t' + str(line_no) + '\t**************************'
        cols.explain()
        print '######################\t' + str(line_no) + '\t##########################'

