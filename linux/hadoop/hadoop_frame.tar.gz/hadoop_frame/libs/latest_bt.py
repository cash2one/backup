#!/usr/bin/env python
#-*- coding:utf-8 -*-
pr = 0
tuned_pp_pr = 1  
tuned_ppim_pr = 2
real_charge_ratio = 3  
target_charge_ratio = 4
charge = 5       
budget = 6       
budget_type = 7  
bt_stat = 8      
pp_shw = 9       
ppim_shw = 10    
budget_id = 11
total_charge = 12    
total_budget = 13
pp_ip_status = 14
ppim_ip_status = 15
ori_pr = 16
pp_impression_prob = 17
ppim_impression_prob = 18
pp_ip_show = 19
ppim_ip_show = 20
ip_cpm = 21
ip_ctr = 22
ip_budget_ratio = 23
ip_hitline = 24
pp_clickq = 25
ppim_clickq = 26
pp_ip_ads_num = 27
ppim_ip_ads_num = 28
length = 29


ip_status = ppim_ip_status
impression_prob = ppim_impression_prob
ip_show = ppim_ip_show
clickq = ppim_clickq
ip_ads_num = ppim_ip_ads_num

def refresh(cmatch):
    global ip_status, impression_prob, ip_show, clickq, ip_ads_num
    if cmatch == 225:
        ip_status = pp_ip_status
        impression_prob = pp_impression_prob
        ip_show = pp_ip_show
        clickq = pp_clickq
        ip_ads_num = pp_ip_ads_num
    elif cmatch == 204:
        ip_status = ppim_ip_status
        impression_prob = ppim_impression_prob
        ip_show = ppim_ip_show
        clickq = ppim_clickq
        ip_ads_num = ppim_ip_ads_num
    else:
        ip_status = ppim_ip_status
        impression_prob = ppim_impression_prob
        ip_show = ppim_ip_show
        clickq = ppim_clickq
        ip_ads_num = ppim_ip_ads_num
