#!/usr/bin/env python
#-*- coding:gbk -*-

import pdb
from UserDict import UserDict
import sys

class apres_parser_t(UserDict):
    '''The helper class to parse an asp ad lineing easily'''
    key_idx = {
        "FCADV_LOGKEY_ADTYPE"  : 1 ,  
        "FCADV_LOGKEY_IDEAID"  : 2 ,  
        "FCADV_LOGKEY_UNITID"  : 3 , 
        "FCADV_LOGKEY_PLANID"  : 4 , 
        "planid"  : 4 , 
        "FCADV_LOGKEY_USERID"  : 5 ,  
        "userid"  : 5 , 
        "FCADV_LOGKEY_WORDID"  : 6 ,  
        "wordid"  : 6 , 
        "FCADV_LOGKEY_QLEFT_AUCTION"  : 7 ,  
        "l_ori_qvalue"  : 7 ,  
        "FCADV_LOGKEY_QRIGHT_AUCTION"  : 8 , 
        "FCADV_LOGKEY_BID"  : 9 ,  
        "bid"  : 9 , 
        "FCADV_LOGKEY_OMITQUERY"  : 10 , 
        "FCADV_LOGKEY_FEA"  : 11 ,  
        "FCADV_LOGKEY_QLEFT_RELIABLE"  : 12 ,  
        "FCADV_LOGKEY_QRIGHT_RELIABLE"  : 13 ,  
        "FCADV_LOGKEY_AUCTION_ADTYPE"  : 14 ,  
        "FCADV_LOGKEY_W1"  : 15 ,  
        "rank"  : 16 ,  
        "FCADV_LOGKEY_RELRANK"  : 17 ,  
        "ori_bid":111,
        "FCADV_LOGKEY_INTENT_W"  : 18 ,  
        "FCADV_LOGKEY_REGION_W"  : 19 ,  
        "FCADV_LOGKEY_MATCH_W"  : 20 , 
        "FCADV_LOGKEY_IS_RG_SENSITIVE"  : 21 , 
        "FCADV_LOGKEY_CS_TYPE"  : 22 ,  
        "FCADV_LOGKEY_QLEFT_GUSUAN"  : 23 ,  
        "FCADV_LOGKEY_QRIGHT_GUSUAN"  : 24 ,  
        "FCADV_LOGKEY_DRATE"  : 25 , 
        "FCADV_LOGKEY_QLEFT_T"  : 26 , 
        "FCADV_LOGKEY_QRIGHT_T"  : 27 , 
        "FCADV_LOGKEY_CMATCH"  : 28 , 
        "FCADV_LOGKEY_WMATCH"  : 29 , 
        "wmatch"  : 29 , 
        "FCADV_LOGKEY_TO_LEFT"  : 30 , 
        "is_ppim_quality"  : 30 , 
        "ppim_quality"  : 30 , 
        "FCADV_LOGKEY_QPP_AUCTION"  : 31 , 
        "ori_pp_q"  : 31 , 
        "FCADV_LOGKEY_QPP_T"  : 32 , 
        "minbid"  : 33 , 
        "FCADV_LOGKEY_TITLE"  : 34 , 
        "title"  : 34 , 
        "FCADV_LOGKEY_DESC1"  : 35 , 
        "desc1"  : 35 , 
        "FCADV_LOGKEY_DESC2"  : 36 , 
        "desc2"  : 36 , 
        "FCADV_LOGKEY_TITLELEN"  : 37 , 
        "FCADV_LOGKEY_DESCLEN"  : 38 , 
        "FCADV_LOGKEY_PPMARK"  : 39 ,  
        "FCADV_LOGKEY_QPP"  : 40 , 
        "ppq"  : 40 , 
        "FCADV_LOGKEY_TO_PP"  : 41 , 
        "is_pp_quality"  : 41 , 
        "pp_quality"  : 41 , 
        "FCADV_LOGKEY_INTENT_ID"  : 42 , 
        "FCADV_LOGKEY_PP_OR_PPIM"  : 43 , 
        "FCADV_LOGKEY_PPIM_PRICE"  : 44 , 
        "ppim_price"  : 44 , 
        "FCADV_LOGKEY_IM_PRICE"  : 45 , 
        "im_price"  : 45 , 
        "FCADV_LOGKEY_PP_PRICE"  : 46 , 
        "pp_price"  : 46 , 
        "FCADV_LOGKEY_CSQ"  : 47 , 
        "FCADV_LOGKEY_ADJ_THR"  : 48 , 
        "FCADV_LOGKEY_CS_ID"  : 49 ,  
        "FCADV_LOGKEY_ECFLAG"  : 50 , 
        "ectag"  : 50 , 
        "FCADV_LOGKEY_MT_ID"  : 51 , 
        "FCADV_LOGKEY_MCID"  : 52 , 
        "FCADV_LOGKEY_USERQ"  : 53 , 
        "FCADV_LOGKEY_PPIM_CPMTHR_TAG"  : 56 , 
        "ppim_cpmthr_tag"  : 56 , 
        "FCADV_LOGKEY_PP_CPMTHR_TAG"  : 57 , 
        "pp_cpmthr_tag"  : 57 , 
        "bidding_framework":150,
        "FCADV_LOGKEY_CS_ID_2"  : 58 ,  
        "FCADV_LOGKEY_CS_ID_3"  : 59 ,  
        "FCADV_LOGKEY_TO_LEFT_EXPERIMENT"  : 60 ,  
        "FCADV_LOGKEY_WCTRL"  : 61 ,  
        "FCADV_LOGKEY_SHOW_URL"  : 62 ,  
        "FCADV_LOGKEY_SESSQ"  : 63 ,  
        "bt_new":116,
        "FCADV_LOGKEY_SESSINFO"  : 64 ,  
        "FCADV_LOGKEY_RANKEXP"  : 65 ,  
        "FCADV_LOGKEY_NSEXP_ADTYPE"  : 66 ,  
        "FCADV_LOGKEY_HC_VALUE"  : 67 ,  
        "hc_value"  : 67 , 
        "FCADV_LOGKEY_BMM_TYPE"  : 68 ,  
        "FCADV_LOGKEY_CLICK_Q"  : 69 ,  
        "clickq"  : 69 , 
        "ori_price": 105,
        "precise_clickq"  : 70 ,  
        "FCADV_LOGKEY_XIJING_TITLE"  : 71 ,  
        "FCADV_LOGKEY_HC_NORM_QVALUE_PP"  : 72 ,  
        "FCADV_LOGKEY_HC_NORM_QVALUE_PPIM"  : 73 ,  
        "FCADV_LOGKEY_HC_NORM_QVALUE_IM"  : 74 ,  
        "FCADV_LOGKEY_BUDGET_THROTTLING_STAT_INFO"  : 118 ,  
        "pp_ub"  : 113 ,  
        "ppim_ub"  : 114 ,  
        "bottom_ub"  : 115 ,
        "disgsp"  : 117 ,  
        "roi"  : 121 , 
        "FCADV_LOGKEY_ROI_PRECISE"  : 130 ,   #asp �ֶκż�1
        "roi_precise"  : 130 ,   #asp �ֶκż�1
        "bi" : 141,  #budget id
        "msa_ubmq" : 175,
        "dra_info" : 260,
    }
    alias = {
        'bidword' : 'term',
        'keyword' : 'term',
    }
    data = {}

    def __init__(self, line = None, safemode = True):
        UserDict.__init__(self)
        self.refresh(line, safemode)

    def refresh(self, line = None, safemode = False):
        try:
            self.cols = []
            self.data = {}
            if line:
                if safemode:
                    de_line = unicode(line, 'gbk')
                    dcols = de_line.split('_')
                    _cols = [c.encode('gbk') for c in dcols]
                else:
                    _cols = line.split('_')
                self.cols.extend(_cols)
            return 0
        except Exception:
            return -1

    def __setitem__(self, key, item):
        if key in self.alias:
            key = self.alias[key]

        self.data[key] = item
        return

    def __len__(self):
        return len(self.cols)

    def __getitem__(self, key):

        if key in self.alias:
            key = self.alias[key]

        if key in self.data:
            return self.data[key]
        
        if isinstance(key, int):
            keyidx = key
        else:
            if key not in self.key_idx:
                print key
                raise KeyError
            keyidx = self.key_idx[key]
        
        keyidx = keyidx - 1

        if keyidx >= len(self.cols):
            raise KeyError
        return self.cols[keyidx]

    def __getattr__(self, key):
        return self[key]

    def dump(self):
        ret = ''
        for i in self.cols:
            ret += i + ','
        print 'cols_len=%s, cols=[%s], data=%s'%(len(self.cols), ret, self.data )
        

class asp_parser_t(UserDict):
    alias = {
        'searchid' : 'sid',
        'sessionid' : 'sid',
        'bidwords' : 'terms',
        'cookie' : 'bd',
        'cookieid' : 'bd',
        'cmatch' : 'spres',
        'pageno' : 'pn',
    }
    data = {
    }
    def __init__(self, line = None):
        UserDict.__init__(self)
        self.refresh(line)

    def refresh(self, line = None, limit_cmatchs = [], limit_tags = [], safemode = False):
        try:
            self.data.clear()
            if not line:
                return 1

            cols = line.split()

            self.data['spres'] = cols[21][6:]
            if (limit_cmatchs) and (self.data['spres'] not in limit_cmatchs):
                return -1

            pres = cols[19].split('=')
            if len(pres)<2:
                return -3
            pres_lst = pres[1].split('_')
            if len(pres_lst)<2:
                return -4
            self.data['tag'] = pres_lst[1]
            self.data['satisfy'] = pres_lst[37]
            self.data['ovl'] = pres_lst[18]
            self.data['zhixin_src'] = pres_lst[54]
            self.data['query_trade'] = pres_lst[59]
            if (limit_tags) and (self.data['tag'] not in limit_tags):
                return -2

            self.data['query'] = cols[0][1:-1]
            self.data['time'] = cols[1][4:]    #
            self.data['src'] = cols[2][4:]    #
            self.data['sid'] = cols[3][2:]
            self.data['pn'] = cols[4][3:]
            self.data['ip'] = cols[5][3:]
            self.data['bd'] = cols[8][3:]
            self.data['dis'] = cols[10][4:]
            self.data['cn'] = cols[16][3:]
            self.data['term'] = cols[12][5:].split(',')
            self.data['winfoid'] = cols[11][3:].split(',')
            
            self.data['apres'] = cols[22][6:]
            self.data['preq_pres'] = cols[19][6:]

            self.data['ads'] = []

            ads_line = self.data['apres'].split(',')
            ad_idx = 0
            for ad_line in ads_line:
                if ad_line:
                    self.data['ads'].append(apres_parser_t(ad_line, safemode))
                    self.data['ads'][ad_idx]['term'] = self.data['term'][ad_idx]
                    self.data['ads'][ad_idx]['winfoid'] = self.data['winfoid'][ad_idx]
                ad_idx += 1

            return 0
        except Exception:
            return -1

    def __iter__(self):
        for ad in self.data['ads']:
            yield ad

    def __getitem__(self, key):
        # get key index in cols
        if key not in self.data:
            if key not in self.alias:
                raise KeyError
            key = self.alias[key]

        if key not in self.data:
            raise KeyError

        return self.data[key]

    def __getattr__ (self, key):
        return self[key]

