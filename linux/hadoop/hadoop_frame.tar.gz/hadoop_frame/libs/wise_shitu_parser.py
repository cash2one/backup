#!/usr/bin/env python
# -*- coding:gb2312 -*-
import sys
from UserDict import UserDict

LENGTH = 106

class wise_shitu_parser_t(UserDict):
    '''The helper class to parse a shitu log line easily
    '''
    idx = {
        'show' : 1,
        'clk' : 2,
        'price' : 3,
        'query' : 4,
        'ip' : 5,
        'cn' : 6,
        'sid' : 7,
        'cookieid' : 8,
        'dis' : 9,
        'cmatch' : 10,
        'wmatch' : 11,  #63��ȷ�� 31��� 15����
        'winfoid' : 12,
        'rank' : 13,
        'tag' : 14,
        'ideaid' : 15,
        'unitid' : 16,
        'planid' : 17,
        'userid' : 18,
        'wordid':19,
        'bid' : 20,
        'Qleft' : 21,
        'Qright' : 22,
        'Qpp' : 23,
        'lq' : 21,
        'term' : 24,
        'bidword' : 24,
        'minbid':33,
        'pid'  : 34,
        'cid'  : 35,
        'time' : 36,
        'ectag' : 42,
        'mt_id' : 43,
        'clickq' : 96,
        'CLICKQ' : 65,
        'pp_rp' :67,
        'ppim_rp': 69,
        'pp_ub':89,
        'ppim_ub':90,
        'smart_bid_tag' : 87,
        'ori_bid' : 88,
        'conf_pv' : 82,
        'ovlexp_id_list' : 73,
        'roi' : 101, 
        'precise_click_q' : 103,
        'clickq_pv':105,
        'hc_value' : 107,
        'disgsp' : 110,
        'newclickq' :102 ,
        'rigq' : 140,
        'bt' :165 ,
        'query_trade' : 124,
        'disgsp_monitor' : 205,
    }
    
    def __init__(self, line = None):
        UserDict.__init__(self)
        self.refresh(line)

    def refresh(self, line = None):
        if line:
            self.cols = ['']
            self.cols.extend(line.strip().split('\t'))
            if len( self.cols ) < LENGTH:
                return -1
            return 0
        return -1

    def __getitem__(self, key):
        # get key index in cols
        if isinstance(key, int):
            keyidx = key
        else:
            if key == 'Q':
                cmatch = self['cmatch']
                if cmatch =='225':
                    return self['Qpp']
                elif cmatch == '201':
                    return self['Qright']
                else:
                    return self['Qleft']

            if key not in self.idx:
                raise KeyError
            keyidx = self.idx[key]

        if keyidx >= len(self.cols):
            raise KeyError


        return self.cols[keyidx]

    def __getattr__(self, key):
        return self[key]
    def explain(self):
        Sorted_lst = sorted( self.idx.items(), lambda x, y: cmp(x[1],y[1]))   
        for item in Sorted_lst :
            key = item[0]
            idx = item[1]
            print '%s [%s] : %s'%(key, idx, self[key])

class ovlexp_id_list_t (set ):
    def __init__(self):
        set.__init__(self)
    def refresh(self, ovlexp_id_list_line):
        self.clear()
        lst = ovlexp_id_list_line.strip().split('#')
        for id in lst:
            id = id.strip()
            if id:
                self.add( id )
        return 0
    def __str__(self):
        ret = ''
        for id in self:
            print id
            ret += id + '#'
        return ret

